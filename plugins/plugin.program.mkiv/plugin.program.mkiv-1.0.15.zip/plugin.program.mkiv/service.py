import sys
import os
import xbmc, xbmcgui,  xbmcaddon
import re
import urllib2
import mk4
import time


MK4Build   =  xbmc.translatePath(os.path.join('special://home/addons/' , 'plugin.program.mkiv.notifications'))
addon_id = 'plugin.program.mkiv'
ADDON = xbmcaddon.Addon(id=addon_id)
Title = "[COLOR red]MK-IV[/COLOR] [COLOR deepskyblue]Wizard[/COLOR]"
my_addon = xbmcaddon.Addon()
dp = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()
AutoUpdateCheck  =  ADDON.getSetting('AutoUpdate')
Check  =  ADDON.getSetting('Update')
UpdateAddons  =  ADDON.getSetting('UpdateAddons')
AutoClean = ADDON.getSetting('AutoClean')
Tracker   =  xbmc.translatePath(os.path.join('special://home/userdata/addon_data/'+ addon_id , 'Tracker.xml'))
TempFile     =  xbmc.translatePath(os.path.join('special://home/userdata/addon_data/'+ addon_id , 'MigrationTrigger.txt'))
NewInstall   =  xbmc.translatePath(os.path.join('special://home/userdata/addon_data/', addon_id))
DummyFile   =  xbmc.translatePath(os.path.join('special://home/','DummyFile'))
AresTracker = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.areswizard','buildinstall' ))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
phoenix = xbmc.translatePath(os.path.join('special://home/addons/','plugin.video.phstreams'))
FirstRun = xbmc.translatePath(os.path.join('special://home/','MK4'))  #Assign a file
Requests = xbmc.translatePath(os.path.join('special://home/addons/','script.module.requests'))

myplatform = mk4.platform()
dp           =  xbmcgui.DialogProgress()
GoogleOne = "http://www.google.com"
GoogleTwo = "http://www.google.co.uk"
BASEURL = "http://mkiv.netne.net" 
nointernet = 0



if os.path.exists(TempFile):
    mk4.RemoveTrigger()
    pass
else: pass


if not os.path.exists(MK4Build):
    if not os.path.exists(DummyFile):
        if not os.path.exists(NewInstall):
            try:
                mk4.WriteFile(DummyFile,'This file tells MK-IV Wizard that it has ran on install and prevents the Splash image from popping up on every start :)')
                mk4.ShowPic('http://mkiv.netne.net/Admin/ProgramSplash/fanart.jpg')
            except:
                pass






 


try:
    response = mk4.OPEN_URL(GoogleOne)
except:
    try:
        response = mk4.OPEN_URL(GoogleTwo)
    except:
        nointernet = 1
        pass

pleasecheck = 0

if os.path.exists(Tracker):
	checkurl = 'http://mkiv.netne.net/Admin/Files/Wizard.xml'
	pleasecheck = 1


if nointernet == 0 and pleasecheck == 1:
    if Check == 'true':
        if os.path.exists(MK4Build):
            if os.path.exists(Tracker):
                vers = open(Tracker, "r")
                regex = re.compile(r'.+?ame="(.+?)".+?ersion="(.+?)"')
                for line in vers:
                    currversion = regex.findall(line)
                    for name,vernumber in currversion:
                        if vernumber > 0:
                            req = urllib2.Request(checkurl)
                            try:
                                response = urllib2.urlopen(req)
                            except:
                                sys.exit(1)
                        
                            link=response.read()  
                            response.close()
                            match = re.compile('.+?ame='+name+'.+?ersion="(.+?)".+?resh="(.+?)"').findall(link)
                            for newversion,fresh in match:
                                if newversion > vernumber:
                                    if fresh =='true' and os.path.exists(phoenix):
                                        choice = xbmcgui.Dialog().yesno( name + " " + newversion + " update available", 'Found a new update for the Build', name + " ver: "+newversion, 'Do you want to install it now?', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
                                        if choice == 1: 
                                            dialog.ok('[COLOR lightskyblue]A FRESH START is required for the update[/COLOR]','Android users select the \'Modified Wipe\' option.','You will recieve an update prompt on restart.')
                                            params=mk4.get_params()
                                            try: mk4.FRESHSTART(params)
                                            except: pass
                                            try:xbmc.executebuiltin('RunPlugin://plugin.program.mkiv')
                                            except: pass
                                        else:
                                            sys.exit(1)
                                    else:
                                        choice = xbmcgui.Dialog().yesno("NEW UPDATE AVAILABLE", 'Found a new update for the Build', name + " ver: "+newversion, 'Do you want to install it now?', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
                                        if choice == 1: 
                                            req = urllib2.Request('http://wizard.mkiv.ca')
                                            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                                            try:
                                                response = urllib2.urlopen(req)
                                            except:
                                                sys.exit(1)
                                            link=response.read()
                                            response.close()
                                            match = re.compile('.+?ame='+name+'.+?rl="(.+?)"').findall(link)
                                            for url in match:				
                                                path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
                                                name = "build"
                                                dp = xbmcgui.DialogProgress()

                                                dp.create(Title,"Downloading ",'', 'Please Wait')
                                                lib=os.path.join(path, name+'.zip')
                                                try:
                                                    os.remove(lib)
                                                except:
                                                    pass
                                    
                                                mk4.download(url, lib, dp)
                                                addonfolder = xbmc.translatePath(os.path.join('special://','home'))
                                                time.sleep(2)
                                                dp.update(0,"", "Extracting Zip Please Wait")
                                                mk4.unzip(lib,addonfolder,dp)
                                                dialog = xbmcgui.Dialog()
                                                dialog.ok(Title, "Your build has succesfully been updated to the latest version.","The Media Center must now force close to complete the update.")							
                                                mk4.killxbmc()
                                        else:
                                            sys.exit(1)
                                        
            else:
                try:
                    link = mk4.OPEN_URL('http://wizard.mkiv.ca').replace('\n','').replace('\r','')
                    localfile = open(Tracker, mode='w+')
                    localfile.write(link)
                    localfile.close()
                    mk4.Toast('[COLOR lime]MK-IV Database Updated[/COLOR]')
                    xbmc.log('===========  MK-IV Database Updated   ==========')
           
                except: 
                    xbmc.log('===========  MK-IV Server appears to be down   ==========')
                    sys.exit()


if UpdateAddons == 'true':
	#Update all repos and packages.
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin("UpdateLocalAddons")

# Sleeper added due to the updating of addons.
time.sleep(60)

if os.path.exists(MK4Build):
    if not os.path.exists(FirstRun):
        try:
            file = open(FirstRun, mode='w')
            time.sleep(.5)
            file.write('This file exists only to let the MK-IV Wizard know that this is not the first time you started the Media Center after updating MK-IV.')
            file.close()
            time.sleep(.5)
            if myplatform == 'android':
                dialog = xbmcgui.Dialog()
                if dialog.yesno(Title, 'The AceStream Engine is required to play some sports section content.', 'After its installed sign into the app and thats it.','Would you like to download and install now?', nolabel='SKIP',yeslabel='Yes'):
                    if dialog.yesno(Title, 'Is your Android device x86 or ARM based', '','(If your not sure try ARM first)', nolabel='ARM',yeslabel='x86'):
                        mk4.INSTALLAPK('acestreamsx86','https://archive.org/download/aappkk/AceStream-3.1.6.0-x86.apk','')
                    #mk4.INSTALLAPK('acestreams','http://dl.acestream.org/products/acestream-engine/android/latest','')
                    else:
                        mk4.INSTALLAPK('acestreamsARM','https://archive.org/download/aappkk/AceStream-3.1.6.0-armv7.apk','')
                else:
                    dialog.ok(Title,'This message will not be shown again','To download AceStreams later go to the MK-IV Wizard','and look in the MK-IV Build Menu.')
            else:
                dialog = xbmcgui.Dialog()
                if dialog.yesno(Title, 'The AceStream Engine is required to play some sports section content.', 'After its installed sign into the app and thats it.','Would you like to download and install now?', nolabel='SKIP',yeslabel='Yes'):
                    dialog.ok(Title,'Press OK to launch your browser to the download page','You only need the engine.','')
                    mk4.OpenWebpage('http://wiki.acestream.org/wiki/index.php/AceStream_3.0/en')
                else:
                    dialog.ok(Title,'This message will not be shown again','To download AceStreams later go to the MK-IV Wizard','and look in the MK-IV Build Menu.')
        except: pass


if AutoClean == "true":
	mk4.CleanOnStart()
