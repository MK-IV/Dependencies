import uploadlog
import sys

try:
    uploadlog.main(argv=None)
except: 
    sys.exit(0)
