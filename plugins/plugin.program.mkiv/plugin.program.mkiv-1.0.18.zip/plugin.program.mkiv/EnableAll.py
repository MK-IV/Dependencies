import mk4
import sys

try:
    mk4.EnableAll()
except: 
    sys.exit(0)
